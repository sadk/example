// JavaScript Document

var fader = new Hongru.fader.init('fader',{
 id:'fader'
});

             