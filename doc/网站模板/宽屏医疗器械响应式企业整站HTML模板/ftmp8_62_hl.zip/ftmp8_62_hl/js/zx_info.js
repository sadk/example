$(document).ready(function(){
   
   $(".mmmzw").fadeTo("fast",0.01);  //切勿删除
   		   
   
   
	});
